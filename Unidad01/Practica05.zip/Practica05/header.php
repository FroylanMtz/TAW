<div class="row">
  <div class="large-3 columns">
    <h1><img src="./img/logo.png"/></h1>
  </div>
  <div class="large-9 columns">
    <ul class="right button-group">
      <li><a href="./index.php" class="button">Ejercicio 1</a></li>
      <li><a href="./sistema_equipos.php" class="button">Ejercicio 2</a></li>
    </ul>
  </div>
</div>