<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_DATABASE', 'Practica04');
	define('DB_PASSWORD', '');
	define('DB_PORT', 3306);

?>