//When document becomes ready (when pages is fully loaded in the browser)
$(document).ready
(
	//Then execute the following function
	function()
	{
		$('fieldset').css('background-color', 'yellow');
	}
);

