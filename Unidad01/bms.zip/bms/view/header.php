<html>
	<head>
		<link rel="stylesheet" href="view/css/style.css">
		<script src="view/js/jquery-3.2.1.min.js"></script>
		<script src="view/js/script.js"></script>
	</head>
	<body>
