<?php 
	include_once "header.php";
	$before_login=true;
	include_once "menu.php";
?>
	<h3>Book Management System</h3>
<?php
	include_once "footer.php";
?>
