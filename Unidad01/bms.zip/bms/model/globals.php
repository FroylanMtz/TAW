<?php
	$db_server="localhost";
	$db_username="bms";
	$db_password="bms";
	$db_name="bms";
?>
